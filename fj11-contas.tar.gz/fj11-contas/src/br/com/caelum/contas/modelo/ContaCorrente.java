package br.com.caelum.contas.modelo;

public class ContaCorrente extends Conta implements Tributavel {

	public String getTipo() {
		return "Conta Corrente";
	}

	@Override
	public void saca(double valor) {
		if (valor < 0) {
			throw new IllegalArgumentException("Você tentou sacar um valor negativo.");
		} else {
			double taxa = 0.10;
			if (saldo < (valor + taxa)) {
				throw new SaldoInsulficienteException("Saldo insulficiente.");
			} else {
				saldo -= (valor + taxa);
			}
		}
	}

	@Override
	public double getValorImposto() {
		double tributo = 0.01;
		return (saldo * tributo);
	}
}
