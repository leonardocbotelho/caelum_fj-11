package br.com.caelum.contas.modelo;

public abstract class Conta implements Comparable<Conta> {
	private String titular;
	protected double saldo;
	private int numero;
	private String agencia;
	private String dataDeAbertura;

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getDataDeAbertura() {
		return dataDeAbertura;
	}

	public void setDataDeAbertura(String dataDeAbertura) {
		this.dataDeAbertura = dataDeAbertura;
	}

	public abstract String getTipo();

	public double getSaldo() {
		return saldo;
	}

	public void deposita(double valor) {
		if (valor < 0) {
			throw new IllegalArgumentException("Você tentou depositar um valor negativo.");
		} else {
			saldo += valor;
		}
	}

	public void saca(double valor) {
		if (valor < 0) {
			throw new IllegalArgumentException("Você tentou sacar um valor negativo.");
		} else {
			if (saldo >= valor) {
				saldo -= valor;
			}
		}
	}

	public void transfere(double valor, Conta conta) {
		this.saca(valor);
		conta.deposita(valor);
	}

	@Override
	public String toString() {
		return "[titular=" + titular.toUpperCase() + ", numero=" + numero + ", agencia=" + agencia + "]";
	}

	@Override
	public boolean equals(Object umObjeto) {
		if (umObjeto instanceof Conta) {
			Conta outraConta = (Conta) umObjeto;
			return (numero == outraConta.numero && agencia.equals(outraConta.agencia));
		}
		return false;
	}
	
	@Override
	public int compareTo(Conta outraConta) {
		return titular.compareTo(outraConta.titular);
	}
}
