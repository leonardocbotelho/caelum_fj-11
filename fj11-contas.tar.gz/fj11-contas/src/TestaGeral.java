
public class TestaGeral {

	public static void main(String[] args) {
		
		String hah = "lalelilolu";
		StringBuilder sb = new StringBuilder(hah);
		
		System.out.println("RESULTADO:");
		System.out.println(sb.reverse());
		
	}
	
}