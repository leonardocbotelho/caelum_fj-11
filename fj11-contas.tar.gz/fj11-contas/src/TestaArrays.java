import br.com.caelum.contas.modelo.Conta;
import br.com.caelum.contas.modelo.ContaCorrente;

public class TestaArrays {

	public static void main(String[] args) {
		
		Conta[] contas = new Conta[10];

		for (int i = 0; i < contas.length; i++) {
			contas[i] = new ContaCorrente();
			contas[i].deposita((i + 1) * 100);
		}

		System.out.println("ANTES:");
		getSaldos(contas);
		
		System.out.println("DEPOIS:");
		for (int i = 0; i < contas.length; i++) {
			System.out.println(contas[i].getSaldo());
		}
		
		double media = 0;
		for (int i = 0; i < contas.length; i++) {
			media += contas[i].getSaldo();
		}
		media /= 10;

		System.out.println(media);
	}
	
	public static void getSaldos(Conta[] contas) {
		for (int i = 0; i < contas.length; i++) {
			System.out.println(contas[i].getSaldo());
			contas[i].deposita(25);
		}
	}
	
}
